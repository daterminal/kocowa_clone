from django.apps import AppConfig


class KocowaConfig(AppConfig):
    name = 'kocowa'
